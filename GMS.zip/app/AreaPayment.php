<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Area;
use App\AreaPayment;
class AreaPayment extends Model
{
  
}
