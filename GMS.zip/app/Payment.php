<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Customer;
use App\Vehicle;

class Payment extends Model
{
   
}
