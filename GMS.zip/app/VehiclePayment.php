<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehiclePayment extends Model
{
    //
}
