@extends('layouts.initial')

@section('content')
     <div class="container m-10">
        <center><img  src="{{ asset('dist/img/error_401.jpg') }}" alt="" srcset=""></center>
     </div>
@endsection
   
 