@extends('layouts.app')

@section('content')
<dashboard-component></dashboard-component>
@endsection
