@extends('layouts.app')

@section('content')
<h1>Hi, </h1>
l<p>Sending Mail from Laravel.</p>
@endsection