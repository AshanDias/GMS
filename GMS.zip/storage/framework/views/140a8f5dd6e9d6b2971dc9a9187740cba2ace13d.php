<?php $__env->startSection('content'); ?>
     <div class="container m-10">
        <center><img  src="<?php echo e(asset('dist/img/error_401.jpg')); ?>" alt="" srcset=""></center>
     </div>
<?php $__env->stopSection(); ?>
   
 
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NIBM\Digree\RWP Project\GMS\resources\views/error.blade.php ENDPATH**/ ?>