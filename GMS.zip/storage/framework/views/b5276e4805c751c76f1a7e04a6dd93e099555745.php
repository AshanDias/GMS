<?php echo e($slot); ?>

<?php /**PATH E:\NIBM\Digree\RWP Project\GMS\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>